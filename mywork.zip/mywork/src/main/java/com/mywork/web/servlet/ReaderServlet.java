package com.mywork.web.servlet;

import com.alibaba.fastjson.JSON;
import com.mywork.pojo.Book;
import com.mywork.pojo.BorrowShow;
import com.mywork.pojo.PageBean;
import com.mywork.pojo.Reader;
import com.mywork.service.ReaderService;
import com.mywork.service.impl.ReaderServiceImpl;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;
import java.io.BufferedReader;
import java.io.IOException;

@WebServlet("/reader/*")
public class ReaderServlet extends BaseServlet{
    private ReaderService readerService = new ReaderServiceImpl();

    public void getBookById(HttpServletRequest req, HttpServletResponse resp) throws IOException, ServletException{

        String bookid = req.getParameter("currentid");
        String readerid = req.getParameter("readerid");


        System.out.println("bookid:"+bookid);
        System.out.println("readerid:"+readerid);

        readerService.getBookById(Integer.parseInt(bookid),Integer.parseInt(readerid));

        resp.setContentType("text/html;charset=utf-8");
        resp.getWriter().write("success");

    }

    public void getReader(HttpServletRequest req, HttpServletResponse resp) throws IOException, ServletException{
        Reader reader = (Reader) req.getSession().getAttribute("reader");

        System.out.println(reader);
        String s = JSON.toJSONString(reader);

        resp.setContentType("text/json;charset=utf-8");
        resp.getWriter().write(s);
    }

    public void jumptoborrow(HttpServletRequest req, HttpServletResponse resp) throws IOException, ServletException{
        resp.setContentType("text/html;charset=utf-8");
        Reader reader = (Reader) req.getSession().getAttribute("reader");
        System.out.println(reader);

        HttpSession session = req.getSession();

        session.setAttribute("reader",reader);

        req.getRequestDispatcher("/readerborrow.html").forward(req, resp);

    }

    public void jumptoget(HttpServletRequest req, HttpServletResponse resp) throws IOException, ServletException{
        resp.setContentType("text/html;charset=utf-8");
        Reader reader = (Reader) req.getSession().getAttribute("reader");
        System.out.println(reader);

        HttpSession session = req.getSession();

        session.setAttribute("reader",reader);

        req.getRequestDispatcher("/readerget.html").forward(req, resp);

    }

    public void renewBookNum(HttpServletRequest req, HttpServletResponse resp) throws IOException, ServletException{
        String id = req.getParameter("currentid");
        readerService.renewBookNum(Integer.parseInt(id));
        resp.setContentType("text/html;charset=utf-8");
        resp.getWriter().write("success");
    }

    public void addBookNum(HttpServletRequest req, HttpServletResponse resp) throws IOException, ServletException{
        String bookid = req.getParameter("currentid");
        readerService.addBookNum(Integer.parseInt(bookid));
        resp.setContentType("text/html;charset=utf-8");
        resp.getWriter().write("success");
    }


    public void renewReturnTime(HttpServletRequest req, HttpServletResponse resp) throws IOException, ServletException{
        String bookid = req.getParameter("currentid");
        String readerid = req.getParameter("readerid");

        readerService.renewReturnTime(Integer.parseInt(bookid),Integer.parseInt(readerid));

        resp.setContentType("text/html;charset=utf-8");
        resp.getWriter().write("success");
    }

    public void selectByPageAndCondition1(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        //1. 接收 当前页码 和 每页展示条数    url?currentPage=1&pageSize=5
        String _currentPage = request.getParameter("currentPage");
        String _pageSize = request.getParameter("pageSize");
        String id = request.getParameter("id");

        Reader reader = (Reader) request.getSession().getAttribute("reader");
        System.out.println("能做到吗："+reader);

        int currentPage = Integer.parseInt(_currentPage);
        int pageSize = Integer.parseInt(_pageSize);

        // 获取查询条件对象
        BufferedReader br = request.getReader();
        String params = br.readLine();//json字符串

        //转为 Brand
        BorrowShow borrowShow = JSON.parseObject(params, BorrowShow.class);
        borrowShow.setReaderid(reader.getId());
        System.out.println("Json转BorrowShow，这个是条件查询的对象:"+borrowShow);


        //2. 调用service查询
        PageBean<BorrowShow> pageBean = readerService.selectByPageAndCondition1(currentPage,pageSize,borrowShow);

        System.out.println("走了Servlet");
        System.out.println(pageBean);

        //2. 转为JSON
        String jsonString = JSON.toJSONString(pageBean);
        //3. 写数据
        response.setContentType("text/json;charset=utf-8");
        response.getWriter().write(jsonString);

        //     response.getWriter().write("success");
    }

    public void returnBook(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException{
        String readerid = request.getParameter("readerid");
        String bookid = request.getParameter("bookid");

        readerService.returnBook(Integer.parseInt(readerid),Integer.parseInt(bookid));

        response.setContentType("text/html;charset=utf-8");
        response.getWriter().write("success");
    }



}
