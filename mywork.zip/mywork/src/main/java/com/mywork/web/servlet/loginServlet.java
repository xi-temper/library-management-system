package com.mywork.web.servlet;

import com.alibaba.fastjson.JSON;
import com.mywork.pojo.Manager;
import com.mywork.pojo.Reader;
import com.mywork.service.LoginService;
import com.mywork.service.impl.LoginServiceImpl;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;
import java.io.IOException;

@WebServlet("/login/*")
public class loginServlet extends BaseServlet{
    private LoginService loginService = new LoginServiceImpl();

    public void Readerlogin(HttpServletRequest req, HttpServletResponse resp) throws IOException, ServletException {


        resp.setContentType("text/html;charset=utf-8");

        String readername = req.getParameter("readername");
        String password = req.getParameter("password");
        String type=req.getParameter("type");
        System.out.println(type);

        if(type.equals("1")){
            Reader reader = loginService.Readerlogin(readername, password);
            HttpSession session = req.getSession();


            if(reader == null){
                resp.getWriter().write("用户名或密码错误");
                resp.sendRedirect(req.getContextPath() + "/login.html");
            }else{
                session.setAttribute("reader",reader);
                System.out.println("loginServlet中："+reader);
                resp.getWriter().write("登录成功");

                req.getRequestDispatcher("/readerget.html").forward(req, resp);

            }

        }else {
            Manager manager = loginService.ReaderloginM(readername, password);
            HttpSession session = req.getSession();

            if(manager == null){
                resp.getWriter().write("用户名或密码错误");
                resp.sendRedirect(req.getContextPath() + "/login.html");
            }else{
                resp.getWriter().write("登录成功");
                req.getRequestDispatcher("/brand.html").forward(req, resp);

            }
        }




    }

}
