package com.mywork.web.servlet;

import com.alibaba.fastjson.JSON;
import com.mywork.pojo.Book;
import com.mywork.pojo.Book1;
import com.mywork.pojo.PageBean;
import com.mywork.service.BookService;
import com.mywork.service.impl.BookServiceImpl;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.BufferedReader;
import java.io.IOException;
import java.util.List;

@WebServlet("/book/*")
public class BookServlet extends BaseServlet{
    private BookService bookService = new BookServiceImpl();

    public void getAllBook(HttpServletRequest req, HttpServletResponse resp) throws IOException, ServletException{
        List<Book> books = bookService.selectAllBook();

        String json = JSON.toJSONString(books);

        resp.setContentType("text/json;charset=utf-8");
        resp.getWriter().write(json);
    }

    public void selectByPageAndCondition(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        //1. 接收 当前页码 和 每页展示条数    url?currentPage=1&pageSize=5
        String _currentPage = request.getParameter("currentPage");
        String _pageSize = request.getParameter("pageSize");

        int currentPage = Integer.parseInt(_currentPage);
        int pageSize = Integer.parseInt(_pageSize);

        // 获取查询条件对象
        BufferedReader br = request.getReader();
        String params = br.readLine();//json字符串

        //转为 Brand
        Book book = JSON.parseObject(params, Book.class);

        //2. 调用service查询
        PageBean<Book> pageBean = bookService.selectByPageAndCondition(currentPage,pageSize,book);

        //2. 转为JSON
        String jsonString = JSON.toJSONString(pageBean);
        //3. 写数据
        response.setContentType("text/json;charset=utf-8");
        response.getWriter().write(jsonString);

   //     response.getWriter().write("success");
    }

    public void addBook(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        BufferedReader br = request.getReader();
        String s = br.readLine();

        Book1 book1 = JSON.parseObject(s, Book1.class);

        bookService.addBook(book1);

        response.getWriter().write("success");
    }

    public void selectById(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException{
        String id = request.getParameter("currentid");

        Book book = bookService.selectById(Integer.parseInt(id));

        String json = JSON.toJSONString(book);
        response.setContentType("text/json;charset=utf-8");
        response.getWriter().write(json);

    }

    public void updateBook(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException{
        BufferedReader br = request.getReader();
        String s = br.readLine();

        Book book = JSON.parseObject(s, Book.class);
        System.out.println(book);

        bookService.updateBook(book);

        response.getWriter().write("success");
    }

    public void deleteByIds(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException{
        BufferedReader br = request.getReader();
        String s = br.readLine();

        int[] ids = JSON.parseObject(s, int[].class);
        bookService.deleteByIds(ids);

        response.getWriter().write("success");

    }

    public void deleteById(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException{
        String id = request.getParameter("currentid");

        bookService.deleteById(Integer.parseInt(id));

        response.getWriter().write("success");
    }




}
