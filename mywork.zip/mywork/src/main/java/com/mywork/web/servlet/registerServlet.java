package com.mywork.web.servlet;

import com.alibaba.fastjson.JSON;
import com.mywork.mapper.ReaderMapper;
import com.mywork.pojo.Reader;
import com.mywork.service.RegisterService;
import com.mywork.service.impl.RegisterServiceImpl;
import org.apache.ibatis.io.Resources;
import org.apache.ibatis.session.SqlSession;
import org.apache.ibatis.session.SqlSessionFactory;
import org.apache.ibatis.session.SqlSessionFactoryBuilder;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStream;
import java.nio.Buffer;

@WebServlet("/register/*")
public class registerServlet extends BaseServlet {
    private RegisterService registerService = new RegisterServiceImpl();

    public void selectReaderByName(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {

        String name = req.getParameter("readername");

        Reader reader = registerService.selectReaderByName(name);


    }

    public void registerReader(HttpServletRequest req, HttpServletResponse resp) throws IOException, ServletException {
//        BufferedReader br = req.getReader();
//        String s = br.readLine();
//        Reader r = JSON.parseObject(s,Reader.class);
        Reader r = new Reader();
        r.setReadername(req.getParameter("readername"));
        r.setPassword(req.getParameter("password"));
        r.setTelephone(req.getParameter("telephone"));

        Reader test = registerService.selectReaderByName(r.getReadername());

        resp.setContentType("text/html;charset=utf-8");

        if (test == null) {
            registerService.registerReader(r);
            resp.getWriter().write("success");
            req.getRequestDispatcher("/login.html").forward(req, resp);

        } else {
            resp.getWriter().write("用户名已存在");
            resp.sendRedirect(req.getContextPath() + "/register.html");

        }
    }




}
