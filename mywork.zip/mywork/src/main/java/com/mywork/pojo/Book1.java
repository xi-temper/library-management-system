package com.mywork.pojo;

public class Book1 {
    private Integer id;
    private String bookname;
    private String bookwriter;
    private String booktype;
    private Integer booknum;
    private String bookprice;
    private String bookdate;

    public Book1(){

    }

    public Integer getId() {
        return id;
    }

    public void setId(Integer id) {
        this.id = id;
    }

    public String getBookname() {
        return bookname;
    }

    public void setBookname(String bookname) {
        this.bookname = bookname;
    }

    public String getBookwriter() {
        return bookwriter;
    }

    public void setBookwriter(String bookwriter) {
        this.bookwriter = bookwriter;
    }

    public String getBooktype() {
        return booktype;
    }

    public void setBooktype(String booktype) {
        this.booktype = booktype;
    }

    public Integer getBooknum() {
        return booknum;
    }

    public void setBooknum(Integer booknum) {
        this.booknum = booknum;
    }

    public String getBookprice() {
        return bookprice;
    }

    public void setBookprice(String bookprice) {
        this.bookprice = bookprice;
    }

    public String getBookdate() {
        return bookdate;
    }

    public void setBookdate(String bookdate) {
        this.bookdate = bookdate;
    }

    @Override
    public String toString() {
        return "Book{" +
                "id=" + id +
                ", bookname='" + bookname + '\'' +
                ", bookwriter='" + bookwriter + '\'' +
                ", booktype='" + booktype + '\'' +
                ", booknum=" + booknum +
                ", bookprice='" + bookprice + '\'' +
                ", bookdate='" + bookdate + '\'' +
                '}';
    }
}
