package com.mywork.pojo;

public class BorrowShow {
    private Integer readerid;
    private Integer bookid;
    private String bookname;
    private String bookwriter;
    private String booktype;
    private String borrowtime;

    public BorrowShow(){

    }

    @Override
    public String toString() {
        return "BorrowShow{" +
                "readerid=" + readerid +
                ", bookid=" + bookid +
                ", bookname='" + bookname + '\'' +
                ", bookwriter='" + bookwriter + '\'' +
                ", booktype='" + booktype + '\'' +
                ", borrowtime='" + borrowtime + '\'' +
                ", returntime='" + returntime + '\'' +
                '}';
    }

    public BorrowShow(Integer readerid, Integer bookid, String bookname, String bookwriter, String booktype, String borrowtime, String returntime) {
        this.readerid = readerid;
        this.bookid = bookid;
        this.bookname = bookname;
        this.bookwriter = bookwriter;
        this.booktype = booktype;
        this.borrowtime = borrowtime;
        this.returntime = returntime;
    }

    public Integer getReaderid() {
        return readerid;
    }

    public void setReaderid(Integer readerid) {
        this.readerid = readerid;
    }

    private String returntime;

    public Integer getBookid() {
        return bookid;
    }

    public void setBookid(Integer bookid) {
        this.bookid = bookid;
    }

    public String getBookname() {
        return bookname;
    }

    public void setBookname(String bookname) {
        this.bookname = bookname;
    }

    public String getBookwriter() {
        return bookwriter;
    }

    public void setBookwriter(String bookwriter) {
        this.bookwriter = bookwriter;
    }

    public String getBooktype() {
        return booktype;
    }

    public void setBooktype(String booktype) {
        this.booktype = booktype;
    }

    public String getBorrowtime() {
        return borrowtime;
    }

    public void setBorrowtime(String borrowtime) {
        this.borrowtime = borrowtime;
    }

    public String getReturntime() {
        return returntime;
    }

    public void setReturntime(String returntime) {
        this.returntime = returntime;
    }
}
