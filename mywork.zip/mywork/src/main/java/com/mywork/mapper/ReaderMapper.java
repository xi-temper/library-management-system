package com.mywork.mapper;

import com.mywork.pojo.*;
import org.apache.ibatis.annotations.Param;
import org.apache.ibatis.annotations.Select;

import java.util.List;

public interface ReaderMapper {

    List<Reader> selectAllReader();

    void registerReader(Reader reader);

    Reader selectReaderByName(String readername);

    Reader Readerlogin(String readername,String password);

    Manager ReaderloginM(@Param("managername") String managername,@Param("password") String password);

    List<Book> selectAllBook();

    List<Book> selectByPageAndCondition(@Param("begin") int begin,@Param("size") int size,@Param("book") Book book);

    int selectTotalCountByCondition(Book book);

    void addBook(Book1 book1);

    Book selectById(Integer id);

    void updateBook(Book book);

    void deleteByIds(@Param("ids") int[] ids);

    void deleteById(Integer id);

    void getBookById(@Param("bookid") Integer bookid,@Param("readerid") Integer readerid);

    void renewBookNum(@Param("id") Integer id);

    void addBookNum(@Param("bookid") Integer bookid);

    void renewReturnTime(@Param("bookid") Integer bookid ,@Param("readerid") Integer readerid);

    List<BorrowShow> selectByPageAndCondition1(@Param("begin") int begin, @Param("size") int size, @Param("borrowShow") BorrowShow borrowShow);

    int selectTotalCountByCondition1(@Param("borrowShow") BorrowShow borrowShow);

    void returnBook(@Param("readerid") Integer readerid,@Param("bookid") Integer bookid);
}
