package com.mywork.service;

import com.mywork.pojo.Book;
import com.mywork.pojo.Book1;
import com.mywork.pojo.PageBean;
import com.mywork.pojo.Reader;
import org.apache.ibatis.annotations.Param;

import java.util.List;

public interface BookService {

    List<Book> selectAllBook();

    PageBean<Book> selectByPageAndCondition(int currentPage, int pageSize, Book book);

    void addBook(Book1 book1);

    Book selectById(Integer id);

    void updateBook(Book book);

    void deleteByIds(int[] ids);

    void deleteById(@Param("id")int id);



}
