package com.mywork.service.impl;

import com.mywork.mapper.ReaderMapper;
import com.mywork.pojo.Book;
import com.mywork.pojo.BorrowShow;
import com.mywork.pojo.PageBean;
import com.mywork.pojo.Reader;
import com.mywork.service.ReaderService;
import com.mywork.util.SqlSessionFactoryUtils;
import org.apache.ibatis.session.SqlSession;
import org.apache.ibatis.session.SqlSessionFactory;

import java.util.List;

public class ReaderServiceImpl implements ReaderService {
    SqlSessionFactory sqlSessionFactory = SqlSessionFactoryUtils.getSqlSessionFactory();

    @Override
    public void getBookById(int bookid, int readerid) {
        SqlSession sqlSession = sqlSessionFactory.openSession();
        ReaderMapper readerMapper = sqlSession.getMapper(ReaderMapper.class);

        readerMapper.getBookById(bookid,readerid);

        sqlSession.commit();
        sqlSession.close();

    }

    @Override
    public void renewBookNum(int id) {
        SqlSession sqlSession = sqlSessionFactory.openSession();
        ReaderMapper readerMapper = sqlSession.getMapper(ReaderMapper.class);

        readerMapper.renewBookNum(id);

        sqlSession.commit();
        sqlSession.close();
    }

    @Override
    public void addBookNum(int bookid) {
        SqlSession sqlSession = sqlSessionFactory.openSession();
        ReaderMapper readerMapper = sqlSession.getMapper(ReaderMapper.class);

        readerMapper.addBookNum(bookid);

        sqlSession.commit();
        sqlSession.close();
    }

    @Override
    public void renewReturnTime(int bookid, int readerid) {
        SqlSession sqlSession = sqlSessionFactory.openSession();
        ReaderMapper readerMapper = sqlSession.getMapper(ReaderMapper.class);

        readerMapper.renewReturnTime(bookid,readerid);
        sqlSession.commit();
        sqlSession.close();
    }

    @Override
    public PageBean<BorrowShow> selectByPageAndCondition1(int currentPage, int pageSize, BorrowShow borrowShow) {
        SqlSession sqlSession = sqlSessionFactory.openSession();
        ReaderMapper readerMapper = sqlSession.getMapper(ReaderMapper.class);


        int begin = (currentPage-1)*pageSize;
        int size = pageSize;

        String bookName = borrowShow.getBookname();
        if(bookName!=null && bookName.length()>0){
            borrowShow.setBookname("%"+bookName+"%");
        }

        String bookWriter = borrowShow.getBookwriter();
        if(bookWriter!=null && bookWriter.length()>0){
            borrowShow.setBookwriter("%"+bookWriter+"%");
        }

        String booktype = borrowShow.getBooktype();
        if(booktype!=null && booktype.length()>0){
            borrowShow.setBooktype("%"+booktype+"%");
        }


        System.out.println("readerServiceImpl里的BorrowSHow" +borrowShow);

        int count = readerMapper.selectTotalCountByCondition1(borrowShow);

        List<BorrowShow> borrowShows = readerMapper.selectByPageAndCondition1(begin, size, borrowShow);

        System.out.println("走了ServiceImpl");
        System.out.println(borrowShows);

        PageBean pageBean = new PageBean();
        pageBean.setRows(borrowShows);
        pageBean.setTotalCount(count);

        sqlSession.close();
        return pageBean;

    }

    @Override
    public void returnBook(Integer readerid, Integer bookid) {
        SqlSession sqlSession = sqlSessionFactory.openSession();
        ReaderMapper readerMapper = sqlSession.getMapper(ReaderMapper.class);

        readerMapper.returnBook(readerid,bookid);

        sqlSession.commit();
        sqlSession.close();
    }
}
