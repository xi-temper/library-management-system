package com.mywork.service.impl;

import com.mywork.mapper.ReaderMapper;
import com.mywork.pojo.Reader;
import com.mywork.service.RegisterService;
import com.mywork.util.SqlSessionFactoryUtils;
import org.apache.ibatis.session.SqlSession;
import org.apache.ibatis.session.SqlSessionFactory;

public class RegisterServiceImpl implements RegisterService {
    SqlSessionFactory sqlSessionFactory = SqlSessionFactoryUtils.getSqlSessionFactory();

    @Override
    public Reader selectReaderByName(String readername) {
        SqlSession sqlSession = sqlSessionFactory.openSession();
        ReaderMapper readerMapper = sqlSession.getMapper(ReaderMapper.class);

        Reader reader = readerMapper.selectReaderByName(readername);

        sqlSession.commit();
        sqlSession.close();
        return reader;

    }

    @Override
    public void registerReader(Reader reader) {
        SqlSession sqlSession = sqlSessionFactory.openSession();
        ReaderMapper readerMapper = sqlSession.getMapper(ReaderMapper.class);

        readerMapper.registerReader(reader);

        sqlSession.commit();
        sqlSession.close();
    }


}
