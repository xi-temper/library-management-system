package com.mywork.service.impl;

import com.mywork.mapper.ReaderMapper;
import com.mywork.pojo.Manager;
import com.mywork.pojo.Reader;
import com.mywork.service.LoginService;
import com.mywork.util.SqlSessionFactoryUtils;
import org.apache.ibatis.annotations.Mapper;
import org.apache.ibatis.session.SqlSession;
import org.apache.ibatis.session.SqlSessionFactory;

public class LoginServiceImpl implements LoginService {
    SqlSessionFactory sqlSessionFactory = SqlSessionFactoryUtils.getSqlSessionFactory();

    @Override
    public Reader Readerlogin(String readername, String password) {
        SqlSession sqlSession = sqlSessionFactory.openSession();
        ReaderMapper readerMapper = sqlSession.getMapper(ReaderMapper.class);

        Reader reader = readerMapper.Readerlogin(readername, password);

        sqlSession.commit();
        sqlSession.close();

        return reader;

    }

    @Override
    public Manager ReaderloginM(String managername, String password) {
        System.out.println("走到ReadloginM");
        System.out.println(managername);
        System.out.println(password);
        SqlSession sqlSession = sqlSessionFactory.openSession();
        ReaderMapper readerMapper = sqlSession.getMapper(ReaderMapper.class);

        Manager manager = readerMapper.ReaderloginM(managername, password);

        sqlSession.commit();
        sqlSession.close();

        return manager;

    }

}
