package com.mywork.service;

import com.mywork.pojo.Manager;
import com.mywork.pojo.Reader;

public interface LoginService {
    Reader Readerlogin(String readername,String password);
    Manager ReaderloginM(String managername, String password);
}
