package com.mywork.service;

import com.mywork.pojo.Book;
import com.mywork.pojo.BorrowShow;
import com.mywork.pojo.PageBean;
import org.apache.ibatis.annotations.Param;

public interface ReaderService {
    void getBookById(@Param("bookid") int bookid,@Param("readerid") int readerid);

    void renewBookNum(@Param("id") int id);

    void addBookNum(@Param("bookid") int bookid);

    void renewReturnTime(@Param("bookid") int bookid,@Param("readerid") int readerid);

    PageBean<BorrowShow> selectByPageAndCondition1(int currentPage, int pageSize, BorrowShow borrowShow);

    void returnBook(@Param("readerid")Integer readerid,@Param("bookid") Integer bookid);
}
