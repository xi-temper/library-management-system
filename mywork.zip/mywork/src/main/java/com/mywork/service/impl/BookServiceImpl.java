package com.mywork.service.impl;

import com.mywork.mapper.ReaderMapper;
import com.mywork.pojo.Book;
import com.mywork.pojo.Book1;
import com.mywork.pojo.PageBean;
import com.mywork.pojo.Reader;
import com.mywork.service.BookService;
import com.mywork.util.SqlSessionFactoryUtils;
import org.apache.ibatis.session.SqlSession;
import org.apache.ibatis.session.SqlSessionFactory;

import java.util.List;

public class BookServiceImpl implements BookService {
    SqlSessionFactory sqlSessionFactory = SqlSessionFactoryUtils.getSqlSessionFactory();

    @Override
    public List<Book> selectAllBook() {
        SqlSession sqlSession = sqlSessionFactory.openSession();
        ReaderMapper readerMapper = sqlSession.getMapper(ReaderMapper.class);

        List<Book> books = readerMapper.selectAllBook();

        sqlSession.close();
        return books;

    }

    @Override
    public PageBean<Book> selectByPageAndCondition(int currentPage, int pageSize, Book book) {
        SqlSession sqlSession = sqlSessionFactory.openSession();
        ReaderMapper readerMapper = sqlSession.getMapper(ReaderMapper.class);

        int begin = (currentPage-1)*pageSize;
        int size = pageSize;

        String bookName = book.getBookname();
        if(bookName!=null && bookName.length()>0){
            book.setBookname("%"+bookName+"%");
        }

        String bookWriter = book.getBookwriter();
        if(bookWriter!=null && bookWriter.length()>0){
            book.setBookwriter("%"+bookWriter+"%");
        }

        String booktype = book.getBooktype();
        if(booktype!=null && booktype.length()>0){
            book.setBooktype("%"+booktype+"%");
        }

        int count = readerMapper.selectTotalCountByCondition(book);

        List<Book> books = readerMapper.selectByPageAndCondition(begin, size, book);



        PageBean pageBean = new PageBean();
        pageBean.setRows(books);
        pageBean.setTotalCount(count);

        sqlSession.close();
        return pageBean;


    }

    @Override
    public void addBook(Book1 book1) {
        SqlSession sqlSession = sqlSessionFactory.openSession();
        ReaderMapper mapper = sqlSession.getMapper(ReaderMapper.class);

        mapper.addBook(book1);

        sqlSession.commit();
        sqlSession.close();
    }

    @Override
    public Book selectById(Integer id) {
        SqlSession sqlSession = sqlSessionFactory.openSession();
        ReaderMapper mapper = sqlSession.getMapper(ReaderMapper.class);

        Book book = mapper.selectById(id);

        sqlSession.commit();
        sqlSession.close();

        return book;
    }

    @Override
    public void updateBook(Book book) {
        SqlSession sqlSession = sqlSessionFactory.openSession();
        ReaderMapper mapper = sqlSession.getMapper(ReaderMapper.class);

        mapper.updateBook(book);

        sqlSession.commit();
        sqlSession.close();

    }

    @Override
    public void deleteByIds(int[] ids) {
        SqlSession sqlSession = sqlSessionFactory.openSession();
        ReaderMapper mapper = sqlSession.getMapper(ReaderMapper.class);

        mapper.deleteByIds(ids);

        sqlSession.commit();
        sqlSession.close();
    }

    @Override
    public void deleteById(int id) {
        SqlSession sqlSession = sqlSessionFactory.openSession();
        ReaderMapper mapper = sqlSession.getMapper(ReaderMapper.class);

        mapper.deleteById(id);

        sqlSession.commit();
        sqlSession.close();
    }


}
