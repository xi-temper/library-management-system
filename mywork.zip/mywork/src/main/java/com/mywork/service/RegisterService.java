package com.mywork.service;

import com.mywork.pojo.Reader;

public interface RegisterService {
    Reader selectReaderByName(String readername);

    void registerReader(Reader reader);
}
