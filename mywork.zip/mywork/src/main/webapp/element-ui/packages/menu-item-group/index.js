import ElMenuItemGroup from '../menu/src/menu-item-group';

/* istanbul ignore next */
ElMenuItemGroup.install = function(Vue) {
  Vue.component(ElMenuItemGroup.name, ElMenuItemGroup);
};

export default ElMenuItemGroup;
